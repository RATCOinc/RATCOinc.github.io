/*
 * This example also demonstrates some usage of annotations
 * You can learn more from: https://docs.oracle.com/javase/tutorial/java/annotations/
 * To generate documentation HTML pages see:
 * 		https://stackoverflow.com/questions/4468669/how-to-generate-javadoc-html-files-in-eclipse
 */
/**
 * A class for working with integer matrices
 * 
 * @author rathin
 */
public class Matrix {
	private int[][] arr;
	private int rows, cols;

	/**
	 * Purposefully disabled direct object creation from outside
	 * by making the default constructor private
	 * @param
	 */
	private Matrix() {
		//dummy
	}

	/**
	 * Disabled direct object creation from outside
	 * by making the this constructor private
	 * 
	 * @param rows	The number of rows in the matrix
	 * @param cols	The number of columns in the matrix
	 * @param allocate Determines whether to allocate the internal array
	 */
	private Matrix(int rows, int cols, boolean allocate) {
		this.rows = rows;
		this.cols = cols;
		if(allocate)
			arr = new int[rows][cols];
	}

	/**
	 * Creates a matrix with the provided data
	 * 
	 * @param rows The number of rows in the matrix
	 * @param cols The number of columns in the matrix
	 * @param data A two dimensional integer array containing matrix data
	 * @param copyData Specifies whether to copy data from the given array
	 * @return A object of type {@code Matrix}
	 */
	public static Matrix createMatrix(int rows, int cols, int[][] data, boolean copyData) {
		if(copyData) {
			Matrix tmp = new Matrix(rows, cols, true);
			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					tmp.arr[i][j] = data[i][j];
				}
			}
			return tmp;
		}
		Matrix tmp = new Matrix(rows, cols, false);
		tmp.arr = data;
		return tmp;
	}

	/**
	 * Creates a null (square) matrix of the specified size
	 * 
	 * @param size The size of the square matrix
	 * @return A object of type {@code Matrix}
	 */
	public static Matrix createNullMatrix(int size) {
		Matrix tmp = new Matrix(size, size, true);
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				tmp.arr[i][j] = 0;
			}
		}
		return tmp;
	}

	/**
	 * Creates a unit (square) matrix of the specified size
	 * 
	 * @param size The size of the square matrix
	 * @return A object of type {@code Matrix}
	 */
	public static Matrix createUnitMatrix(int size) {
		Matrix tmp = new Matrix(size, size, true);
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				if (i == j)
					tmp.arr[i][j] = 1;
				else
					tmp.arr[i][j] = 0;
			}
		}
		return tmp;
	}

	/**
	 * Creates a deep copy the current matrix
	 * 
	 * @return A object of type {@code Matrix} with cloned data
	 */
	public Matrix cloneMatrix() {
		return createMatrix(this.rows, this.cols, this.arr, true);
	}

	/**
	 * Prints the current matrix in structured form
	 */
	public void displayMatrix() {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < rows; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println("");
		}
	}

	/**
	 * Performs a matrix addition
	 * 
	 * @param a {@code Matrix} A
	 * @param b {@code Matrix} B
	 * @return A new matrix containing the result of A+B
	 */
	public static Matrix add(Matrix a, Matrix b) {
		if (a.rows != b.rows || a.cols != b.cols) {
			System.out.println("Dimension Mismatch");
			return null;
		}
		Matrix tmp = new Matrix(a.rows, a.cols, true);
		for (int i = 0; i < a.rows; i++) {
			for (int j = 0; j < a.cols; j++) {
				tmp.arr[i][j] = a.arr[i][j] + b.arr[i][j];
			}
		}
		return tmp;
	}

	/**
	 * Performs a matrix subtraction
	 * 
	 * @param a {@code Matrix} A
	 * @param b {@code Matrix} B
	 * @return A new matrix containing the result of A-B
	 */
	public static Matrix substract(Matrix a, Matrix b) {
		if (a.rows != b.rows || a.cols != b.cols) {
			System.out.println("Dimension Mismatch");
			return null;
		}
		Matrix tmp = new Matrix(a.rows, a.cols, true);
		for (int i = 0; i < a.rows; i++) {
			for (int j = 0; j < a.cols; j++) {
				tmp.arr[i][j] = a.arr[i][j] - b.arr[i][j];
			}
		}
		return tmp;
	}

	/**
	 * Multiplies a scalar to a matrix
	 * 
	 * @param k The scalar integer
	 * @param a {@code Matrix} A
	 * @return A new matrix containing the result of k.A
	 */
	public static Matrix multiply(int k, Matrix a) {
		Matrix tmp = new Matrix(a.rows, a.cols, true);
		for (int i = 0; i < a.rows; i++) {
			for (int j = 0; j < a.cols; j++) {
				tmp.arr[i][j] = a.arr[i][j] * k;
			}
		}
		return tmp;
	}

	/**
	 * Performs a matrix multiplication
	 * 
	 * @param a {@code Matrix} A
	 * @param b {@code Matrix} B
	 * @return A new matrix containing the result of AxB
	 */
	public static Matrix multiply(Matrix a, Matrix b) {
		if (a.cols != b.rows) {
			System.out.println("Dimension Mismatch");
			return null;
		}
		Matrix tmp = new Matrix(a.rows, b.cols, true);
		for (int i = 0; i < tmp.rows; i++) {
			for (int j = 0; j < tmp.cols; j++) {
				tmp.arr[i][j] = 0;
				for (int k = 0; k < a.cols; k++) {
					tmp.arr[i][j] += a.arr[i][k] * b.arr[k][j];
				}
			}
		}
		return tmp;
	}
	
	/**
	 * Transposes a given matrix
	 * 
	 * @param a {@code Matrix} A
	 * @return The transposed matrix A<sup>T</sup>
	 */
	public static Matrix transpose(Matrix a) {
		Matrix tmp = new Matrix(a.cols, a.rows, true);
		for (int i = 0; i < a.rows; i++) {
			for (int j = 0; j < a.cols; j++) {
				tmp.arr[j][i] = a.arr[i][j];
			}
		}
		return tmp;
	}
}
