
public class SortedLinkedList {
	private class Node {
		int data;
		Node next;
		
		public Node(int data) {
			this(data, null);
		}
		
		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
	}
	
	private Node root;
	
	public SortedLinkedList() {
		root = null;
	}
	
	public void insert(int value) {
		Node tmp = root;
		if(root == null)
			root = new Node(value);
		
		while(tmp.next != null) {
			if(tmp.next.data > value)
				break;
		}
		Node newNode = new Node(value, tmp.next);
		tmp.next = newNode;
	}
	
	//deletes first occurrence, if exists
	public void delete(int value) {
		Node tmp = root;
		if(root == null)
			return;
		
		if(root.data == value)
			root = root.next;
		
		while(tmp.next != null) {
			if(tmp.next.data == value)
				break;
		}
		tmp.next = tmp.next.next; //skip next node, gc will delete it
	}
	
	public boolean doesContain(int value) {
		//left as an exercise
		return false;
	}
}
