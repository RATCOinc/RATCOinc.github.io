/*rewritten*/
public class Complex {
	int real, img;
	
	public Complex() {
		this(0, 0);
	}
	
	public Complex(int real, int img) {
		this.real = real;
		this.img = img;
	}

	private void display() {
		System.out.println(real + "+i(" + img + ")");
	}
	
	public static void main(String[] args) {
		Complex c1 = new Complex(); //invokes the default constructor
		c1.display();
		Complex c2 = new Complex(5, -3);
		c2.display();
	}
}
