
public class Stack {
	private int top;
	private int[] arr;
	private final static int SIZE = 10; //a class constant
	
	static {
		System.out.println("Stack class loaded");
	}
	
	public Stack() {
		top = 0;
		arr = new int[Stack.SIZE];
	}
	
	public void push(int x) {
		if(top == Stack.SIZE) {
			System.out.println("FULL");
		} else {
			arr[++top] = x;
		}
	}
	
	public int pop( ) {
		if (top == 0) {
			System.out.println("EMPTY");
			return 0;
		} else {
			return arr[top--];
		}
	}
	
	public static void main(String[] args) {
		Stack s = new Stack();
		s.push(10);
		s.push(20);
		System.out.println(s.pop());
		System.out.println(s.pop());
	}
}
