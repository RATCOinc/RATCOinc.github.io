
public class Complex {
	int real, img;
	
	public Complex() { //default constructor
		real = img = 0;
	}
	
	//constructor overloading
	public Complex(int a, int b) {
		real = a;
		img = b;
	}

	private void display() {
		System.out.println(real + "+i(" + img + ")");
	}
	
	public static void main(String[] args) {
		Complex c1 = new Complex(); //invokes the default constructor
		Complex c2 = c1;
		c1.real = 10;
		c2.img = 20;
		c1.display(); //experimenting with object references
		c2.display();
		
		
		Complex c3 = new Complex(5, -3); //invokes the parameterized constructor
		c3.display();
	}
}
