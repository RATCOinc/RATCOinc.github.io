import java.awt.BorderLayout;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

public class Test extends JFrame{
	
	imagePanel panel;
	JScrollPane scroll;
	
	JFileChooser fc;
	
	public Test() {
		panel = new imagePanel();
		scroll = new JScrollPane(panel);
		scroll.setAutoscrolls(true);
		this.add(scroll,BorderLayout.CENTER);
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}	

	public static void main(String[] args) {
		new Test();
	}
}
