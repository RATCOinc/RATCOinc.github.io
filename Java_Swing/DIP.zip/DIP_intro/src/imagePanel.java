import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class imagePanel extends JPanel{

	File f;
	BufferedImage img;
	
	JPanel panel;
	
	public imagePanel() {
		f = new File("f.png");
		try {
			img = ImageIO.read(f);
		} catch (IOException e) {
			System.out.println("Could not read");
			System.exit(0);
		}
		this.setPreferredSize(new Dimension(img.getWidth(),img.getHeight()));
		repaint();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(img, 0, 0, null);
	}
	
	
}
