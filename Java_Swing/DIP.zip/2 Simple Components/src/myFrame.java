import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class myFrame extends JFrame implements ActionListener  {

	JPanel componentPanel;
	
	JLabel label;
	JButton button;
	JTextField text;
	
	public myFrame() {
		componentPanel = new JPanel();
		text = new JTextField(20);
		label = new JLabel("ABCD");
		button = new JButton("Click");
		
		button.addActionListener(this);
		
		componentPanel.add(text);
		componentPanel.add(button);
		componentPanel.add(label);
		
		this.add(componentPanel);
		
		this.pack();
		this.setVisible(true);
		
		setTitle("Simple Components");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	
	public static void main(String[] args) {
		new myFrame();
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if(ae.getActionCommand().equalsIgnoreCase("Click")) {
			label.setText(text.getText());
			this.pack();
		}
		
	}

}
