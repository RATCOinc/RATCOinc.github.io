import javax.swing.JFrame;
import javax.swing.JLabel;


public class myFrame extends JFrame {

	JLabel label;
	myFrame() {
		label = new JLabel("Hello World");
		this.add(label); //adds the label to this frame
		this.setSize(100, 100);
		this.setVisible(true);
		
		setTitle("Hello World");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	public static void main(String args[]) {
		new myFrame(); //instantiate a frame
	}


}
