import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class imagePanel extends JPanel{

	Test parent;
	
	File f;
	BufferedImage img;
	
	JPanel panel;
	
	public imagePanel(Test parent) {
		this.parent = parent;
	}
	
	public void readImage() {
		f = parent.fc.getSelectedFile();
		try {
			img = ImageIO.read(f);
			this.setPreferredSize(new Dimension(img.getWidth(),img.getHeight()));
			repaint();
			parent.pack();
		} catch (IOException e) {
			System.out.println("Could not read");
			System.exit(0);
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(img, 0, 0, null);
	}
	
	
}
