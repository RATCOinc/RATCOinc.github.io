import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

public class Test extends JFrame{
	
	imagePanel panel;
	JScrollPane scroll;
	
	JButton select;
	JFileChooser fc;
//	Boolean fileSelected;
	
	public Test() {
//		fileSelected = false;
		fc = new JFileChooser(".");
		select = new JButton("Choose");
		this.add(select,BorderLayout.NORTH);
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ae) {
				int result = fc.showOpenDialog(panel);
				if(result == JFileChooser.APPROVE_OPTION) {
//					fileSelected = true;
					panel.readImage();
				}
			}
		});
		
		panel = new imagePanel(this);
		
		scroll = new JScrollPane(panel);
		scroll.setAutoscrolls(true);
		this.add(scroll,BorderLayout.SOUTH);
//		this.pack();
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}	

	public static void main(String[] args) {
		new Test();
	}
}
