import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Test extends JFrame{
	
	JPanel topPanel;
	imagePanel imgPanel;
	JScrollPane scroll;
	
	JButton select;
	JFileChooser fc;
	Boolean fileSelected;
	
	JButton convert;
	JComboBox<String> c;
	
	public Test() {
		topPanel = new JPanel();
		fileSelected = false;
		fc = new JFileChooser(".");
		select = new JButton("Choose");
		topPanel.add(select);
		select.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ae) {
				int result = fc.showOpenDialog(imgPanel);
				if(result == JFileChooser.APPROVE_OPTION) {
					fileSelected = true;
					imgPanel.readImage();
				}
			}
		});
		
		c = new JComboBox<>();
		c.addItem("RED");
		c.addItem("GREEN");
		c.addItem("BLUE");
		topPanel.add(c);
		
		convert = new JButton("Convert");
		convert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ae) {
				if(fileSelected)
					imgPanel.convert();
				else
					select.doClick();
			}
		});
		topPanel.add(convert);
		
		this.add(topPanel,BorderLayout.NORTH);
		
		imgPanel = new imagePanel(this);
		
		scroll = new JScrollPane(imgPanel);
		scroll.setAutoscrolls(true);
		this.add(scroll,BorderLayout.SOUTH);
//		this.pack();
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}	

	public static void main(String[] args) {
		new Test();
	}
}
