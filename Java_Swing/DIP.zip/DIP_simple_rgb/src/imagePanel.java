import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class imagePanel extends JPanel{

	Test parent;
	
	File f;
	BufferedImage img;
	BufferedImage img2;
	
	JPanel panel;
	
	public imagePanel(Test parent) {
		this.parent = parent;
	}
	
	public void readImage() {
		f = parent.fc.getSelectedFile();
		try {
			img2 = img = ImageIO.read(f);
			this.setPreferredSize(new Dimension(img.getWidth(),img.getHeight()));
			
			repaint();
			parent.pack();
		} catch (IOException e) {
			System.out.println("Could not read");
			System.exit(0);
		}
	}
	
	public void convert() {
		int rgb = parent.c.getSelectedIndex();
		img2 = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
		switch (rgb) {
			case 0: //RED
				for (int i = 0; i < img.getWidth(); i++) {
					for (int j = 0; j < img.getHeight(); j++) {
						Color c = new Color(img.getRGB(i, j));
						Color c2 = new Color(c.getRed(),0,0);
						img2.setRGB(i, j, c2.getRGB());
					}
				}
				break;
			case 1: //GREEN
				for (int i = 0; i < img.getWidth(); i++) {
					for (int j = 0; j < img.getHeight(); j++) {
						Color c = new Color(img.getRGB(i, j));
						Color c2 = new Color(0,c.getGreen(),0);
						img2.setRGB(i, j, c2.getRGB());
					}
				}
				break;
			case 2: //BLUE
				for (int i = 0; i < img.getWidth(); i++) {
					for (int j = 0; j < img.getHeight(); j++) {
						Color c = new Color(img.getRGB(i, j));
						Color c2 = new Color(0,0,c.getBlue());
						img2.setRGB(i, j, c2.getRGB());
					}
				}
				break;
			default:
				break;
		}
		repaint();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(img2, 0, 0, null);
	}
	
	
}
