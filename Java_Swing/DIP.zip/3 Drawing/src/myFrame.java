import javax.swing.JFrame;


public class myFrame extends JFrame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
