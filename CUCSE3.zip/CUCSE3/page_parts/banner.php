<!--cu banner-->
<div class="w3-row">
    <div class="w3-col">
        <img src="pic/CU_BANNER.gif" alt="CUCSE Banner" width="100%">
    </div>
</div>
<br>