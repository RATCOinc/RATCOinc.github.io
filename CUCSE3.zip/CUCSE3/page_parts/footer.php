<!--footer-->
<br>
<div class="w3-row w3-black w3-card-4 w3-center">
    Copyright &copy; 2016
    <b>CUCSE</b>
    All Rights Reserved
</div>